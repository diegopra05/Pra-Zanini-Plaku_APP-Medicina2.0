package progettomedicina;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import android.annotation.SuppressLint;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.progettomedicina.R;

import progettomedicina.helpers.StringHelper;


public class MainActivity2 extends AppCompatActivity {

    private Button btn;
    private Button login;
    EditText email;
    EditText psw;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btn=findViewById(R.id.btnEsci);
        login=findViewById(R.id.button5);
        email=findViewById(R.id.email);
        psw=findViewById(R.id.password);

        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                authenticateUser();
            }
        });
    }
    public void authenticateUser(){
        if(!validateEmail() || !validatePassword()){
            return;
        }

        RequestQueue queue = Volley.newRequestQueue(MainActivity2.this);

        String url = "http://192.168.1.114:9080/api/v1/user/login";

        HashMap<String, String> params = new HashMap<String, String>();
        params.put("email", email.getText().toString());
        params.put("password", psw.getText().toString());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, new JSONObject(params), new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try{
                    String nome = (String)response.get("nome");
                    String cognome = (String)response.get("cognome");
                    String email = (String)response.get("email");

                    Intent goToProfile = new Intent(MainActivity2.this, MainActivity3.class);

                    goToProfile.putExtra("nome", nome);
                    goToProfile.putExtra("cognome", cognome);
                    goToProfile.putExtra("email", email);

                    startActivity(goToProfile);
                    finish();

                }catch(JSONException e){
                    e.printStackTrace();
                    System.out.println(e.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                System.out.println(error.getMessage());
                Toast.makeText(MainActivity2.this, "Login fallito", Toast.LENGTH_LONG).show();
            }
        });

        queue.add(jsonObjectRequest);
    }
    public boolean validateEmail(){
        String email_e = email.getText().toString();

        if(email_e.isEmpty()){
            email.setError("L'email non deve essere vuota");
            return false;
        }
        else if(!StringHelper.regexEmailValidationPattern(email_e)){
            email.setError("Indirizzo email non valido");
            return false;
        }
        else{
            email.setError(null);
            return true;
        }
    }
    public boolean validatePassword(){
        String pass = psw.getText().toString();

        if(pass.isEmpty()){
            psw.setError("La password non può essere vuota");
            return false;
        }
        else{
            psw.setError(null);
            return true;
        }
    }
}